import os
import pickle

from discord.ext import commands

import modules.chat as chat

bot = commands.Bot(command_prefix="jp/")
userids = {}
owner = 557644109645611018

warning = """This AI is in Pre-Alpha, and when you talk to it, your emotions and what you say to it is being saved. This is so JarvisProject can learn phrases and sentences.
Thank you for participating in the Project!"""

npath = os.path.expanduser("~") + "/Documents/JarvisProject/bot"
disabledservers = [799789347729309696, 831312769600192542]
global savedusers
with open(npath + "/savedusers.pkl", "rb") as f:
    savedusers = pickle.load(f)

@bot.event
async def on_ready():
    print("Bot is ready")
    print(bot.user.name)
    print(bot.user.id)
    print('------')

@bot.event
async def on_message(message):
    global savedusers
    if not message.author.id in savedusers:
        savedusers.append(message.author.id)
        await message.channel.send(warning)
        with open(npath + "/savedusers.pkl", "wb+") as f:
            pickle.dump(savedusers, f)
    
    if ((not message.author.id == bot.user.id) and (not message.channel.id == 945352841600573500)):
        try:
            if message.guild.id in disabledservers:
                return
        except:
            pass
        if not message.author.id in userids:
            print("Creating Chat Engine for user: " + str(message.author.id) + "...")
            userids[message.author.id] = chat.Main(name=message.author.id, bypass=True, speech=False)
            userids[message.author.id].ret = True
            print("Chat Engine Created for user: " + str(message.author.id) + "!")

        await message.channel.send(userids[message.author.id].talk(message.content))
        userids[message.author.id].checktalk()
    
    await bot.process_commands(message)

@bot.command()
async def remove(ctx, userid: int):
    global userids
    if ((ctx.author.id == owner) and (ctx.channel.id == 945352841600573500)):
        try:
            userids.pop(userid)
            await ctx.send("User's Chat Engine was removed!")
        except:
            await ctx.send("That user does not have a Chat Engine!")

@bot.command()
async def clear(ctx):
    global userids
    if ((ctx.author.id == owner) and (ctx.channel.id == 945352841600573500)):
        try:
            userids = {}
            await ctx.send("All Chat Engines Cleared!")
        except Exception as e:
            await ctx.send("Error")
            print(str(e))
    
@bot.command()
async def create(ctx, userid: int):
    global userids
    if ((ctx.author.id == owner) and (ctx.channel.id == 945352841600573500)):
        if not userid in userids:
            print("Creating Chat Engine for user: " + str(userid) + "...")
            userids[userid] = "talk" + str(userid)
            userids[userid] = chat.Main(bypass=True, speak=False)
            userids[userid].ret = True
            print("Chat Engine Created for user: " + str(userid) + "!")
            await ctx.send("Chat Engine Created for user: " + str(userid) + "!")
        else:
            await ctx.send("User already has a Chat Engine!")

@bot.command()
async def list(ctx):
    global userids
    if ((ctx.author.id == owner) and (ctx.channel.id == 945352841600573500)):
        userlist = []
        for key in userids.keys():
            key = "<@" + str(key) + ">"
            userlist.append(key)
        
        userlist = " ".join([str(x) for x in userlist])
        await ctx.send(key)

@bot.command()
async def save(ctx, user):
    global userids
    if ((ctx.author.id == owner) and (ctx.channel.id == 945352841600573500)):
        tmp = userids[int(user)]
        tmp.savemodel(overwrite=True)
        tmp = None

#bot.run("OTQ1MzEwMjgwNTM4MjcxNzU1.YhOTFg.femWI45vHZe2_qR1-QTd_Z3z9x0")
bot.run("OTQ1MzEwMjgwNTM4MjcxNzU1.Yjn2Sg.ljJlITaQ-pVTKVIx8cuEkcAGiZ8")
#bot.run("ODMwOTU4MjQ2NTE2NDkwMjQz.YHOQLA.CJK-sPHAPsnhHgyNkNcrcYeAuYM")
