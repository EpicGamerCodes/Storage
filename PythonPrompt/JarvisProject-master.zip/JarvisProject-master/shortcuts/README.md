# What is this folder?

This folder contains all supported apps of the 'start' voice command. These are only for the defult install location.