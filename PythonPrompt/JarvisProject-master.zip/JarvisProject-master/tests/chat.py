import os
import sys
import shutil

from loguru import logger

sys.path.insert(0, os.getcwd())
import modules.chat as chat

@logger.catch
def main() -> dict:
    # Prepare
    checks = {}
    checks["speech"] = "In progress"
    checks["text"] = "Pending"
    checks["checktalk"] = "Pending"
    checks["save"] = "Pending"
    checks["restore"] = "Pending"

    # Load talk_speech
    checks["speech"] = "In progress"
    talk_speech = chat.Main("tests", bypass=True, speak=True)
    talk_speech.talk("Testing for tests, can you hear this?")
    while checks["speech"] == "In progress":
        speech_check = input("Did you hear a responce from JarvisProject? (Y/N): ")
        if speech_check.lower() == "y":
            checks["speech"] = "Works"
        else:
            checks["speech"] = "Fail!"
    talk_speech = None
    
    # Load talk_text
    checks["text"] = "In progress"
    talk_text = chat.Main("tests", bypass=True, speak=False)
    talk_text.ret = True
    returndata = talk_text.talk("Hello, how are you?")
    if bool(returndata) is True:
        checks["text"] = "Works"
    else:
        checks["text"] = "Fail!"
    
    # checktalk
    checks["checktalk"] = "In progress"
    talk_text.ret = False
    talk_text.checktalk()
    talk_text.talk("Welcome!")
    talk_text.checktalk()
    talk_text.talk("I am so happy!")
    talk_text.checktalk()
    talk_text.talk("Are you happy?")
    talk_text.checktalk()
    if ((bool(talk_text.data.emotions) is True) and (bool(talk_text.data.usremotions) is True)):
        print("checktalk Complete!")
        checks["checktalk"] = "Works"
    else:
        checks["checktalk"] = "Fail!"

    # save checks
    checks["save"] = "In progress"
    talk_text.savemodel()
    if os.path.isdir(os.path.expanduser('~') + "/Documents/JarvisProject/profiles/tests"):
        checks["save"] = "Works"
    else:
        checks["save"] = "Fail!"
    try:
        shutil.rmtree(os.path.expanduser('~') + "/Documents/JarvisProject/profiles/tests")
    except Exception:
        checks["save"] = "Saved, but not with the correct name"

    # Restore checks
    chat.Restore.save("testing.pkl", data = talk_text)
    compare = talk_text.data.usrrequest
    talk_text = None
    ai = chat.Restore.load("testing.pkl")
    os.remove(os.path.expanduser('~') + "/Documents/JarvisProject/profiles/Restore/testing.pkl")
    if ai.data.usrrequest == compare:
        checks["restore"] = "Works"
    else:
        checks["restore"] = "Fail!"

    return checks

if __name__ == "__main__":
    checks = main()
    for k, v in checks.items():
        if v == "Fail!":
            print(f"ERROR: A check failed! ({k})")
        else:
            print(k + ": " + v)