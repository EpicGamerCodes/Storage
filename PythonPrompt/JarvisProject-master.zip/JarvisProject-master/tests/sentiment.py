import os
import sys

sys.path.insert(0, os.getcwd())
import modules.engine.sentiment as sentiment

def main() -> dict:
    # checks
    checks = {}
    checks["Happy"] = "In progress"

    if sentiment.check("I'm so happy!") == 0.6468:
        checks["Happy"] = "Works"
    else:
        checks["Happy"] = "Fail!"
    
    return checks

if __name__ == "__main__":
    checks = main()
    for k, v in checks.items():
        if v == "Fail!":
            print(f"ERROR: A check failed! ({k})")
        else:
            print(k + ": " + v)