# JarvisProject

JarvisProject is a Python Virtual Assistant that you can ask it shall know.
It contains an intelligent AI that can talk to you in any language.

## Requirements

- Windows 10 / 11 (Works on Linux / MacOS but issues may occur)
- Python 3.8+ (Recommended Python 3.9.10)
- Minimum Storage free: 4GB

To use the AI, you need to have at least ~2GB of storage free. (1.8GB Download). To use the 'FastBoot' feature, 3GB will be needed.

## Usage
Install the fonts in [/fonts](https://github.com/EpicGamerCodes/JarvisProject/tree/master/fonts) for [/modules/gui.py](https://github.com/EpicGamerCodes/JarvisProject/blob/master/modules/gui.py#L91) to work correctly.

Windows:

```python
git clone https://github.com/EpicGamerCodes/JarvisProject
cd JarvisProject
python main.py
```

Linux / MacOS:

```python
git clone https://github.com/EpicGamerCodes/JarvisProject
cd JarvisProject
python3 main.py
```

(Instead of 'git clone' you could download a zip file of the repository from [here](https://github.com/EpicGamerCodes/JarvisProject/archive/master.zip) and extract it.)

Running 'main.py' will copy / make any critical files to "/Documents/JarvisProject".
The Python files are still needed, and you still need to launch JarvisProject with the same 'main.py'.

Use the taskbar tray icon to interact with the project.

## Installation

This allows you to run JarvisProject from anywhere (using CMD / Windows Terminal, e.g: start jarvisproject)
Clone this repo and run these command:

Windows:

```python
pip install -r requirements.txt
python main.py --install
```

Linux / MacOS:

```python
python3 -m pip install -r requirements.txt
python3 main.py --install
```

This installs JarvisProject to the Documents folder (/JarvisProject/app) and adds it to the User PATH.

## Contributing

Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.

## License

[MIT](https://choosealicense.com/licenses/mit/)

# main.py

This python script loads up the JarvisProject modules and starts them.

## Start individual modules

```python
python main.py --run [module name]
```

## Command Line Flags

(Works with the compiled build and the latest version)

```--offline``` Uses all the offline modules and does not use the internet (Enabled by default if the device is not connected to the internet).

```--dev``` Shows log in the terminal window.

```--install / -i``` [Installs JarvisProject to Program Files](##Installation (Gobal))

```--no-voice / -nv``` Disables the voice in listen.py

```--no-tray / -nt``` Disables the system tray icon in taskbar.py

```--ignore-start-aliases / -isa``` Ignores the "start" Voice Command app aliases in listen.py

```--run [module name]``` Runs the given module name as a new process
