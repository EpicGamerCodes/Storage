# What is this folder?

This folder contains set offline voice files for JarvisProject to use when not connected to the internet.