# Modules Help

## chat.py

To start the module as usual, just run the file, and the 'steps' will default at 100, so you can talk to JarvisProject for that amount of times.
To change this, open the Python Interpreter and run this:

```python
from chat import Main
Main(no=10)
```

Where 10 is the number you want 'steps' to be.

There are multiple arguments for Main(), these are:

```python
Main(name: str, no: int = 100, speak = "both", bypass: bool = False, listen: bool = False)
```

`name: str` - A name for the instance, use `instance.info()` to get details or to just get the name, use the variable `Main.name_of_instances`.\
`no: int` - How many times to converse with JarvisProject. (Defaults to 100)\
`speak` - What output mode to use. True only speaks the output, False only displays the output and "both" speaks and displays the output. (Defaults to "both")\
`bypass: bool` - This displays no text on the screen and skips all user inputs. If the 'no' variable is set to 100, 'no' automatically gets set to 0, also disabling user input for JarvisProject to give an output to. (Defaults to False)\
`listen: bool` - If enabled, the microphone will be used as user input for JarvisProject to give an output to. (Defaults to False)\
`temperature: float`: Increase to let the AI go on a tanget, use a low number to let it speak in short sentences. (Defaults to 0.75).

For example, if you wanted to import this module and be able to run it without reloading the module on every invoke, use this code:

```python
main = Main("Example1", bypass=True) # Enables bypass to quickly load, skipping all user input 
main.ret = True # Sets return to True, main.talk() returns data now
text = "Example Text to give to JarvisProject"
print(main.talk(text)) # Print JarvisProject's responce to the text
```

chat.py also accepts CLI arguments. These are:

```python
--profile
   |---> make 
   |---> delete
   |---> rename
```

For example, to make a Profile with the name 'Example1', the following command would be used:

```python
./chat.py --profile make Example1
