import requests
from bs4 import BeautifulSoup
import random

class Scraper:

	def __init__(self):
		self.bounce_log = []
	def BounceArticles(self, website: str):
		response = requests.get(url=website)
	
		soup = BeautifulSoup(response.content, 'html.parser')

		title = soup.find(id="firstHeading")
		self.bounce_log.append(title.text)
		print(title.text)

		allLinks = soup.find(id="bodyContent").find_all("a")
		random.shuffle(allLinks)
		linkToScrape = 0

		for link in allLinks:
		# We are only interested in other wiki articles
			if link['href'].find("/wiki/") == -1: 
				continue

		# Use this link to scrape
			linkToScrape = link
			break

		self.BounceArticles("https://en.wikipedia.org" + linkToScrape['href'])

if __name__ == "__main__":
	s = Scraper()
	s.BounceArticles("https://en.wikipedia.org/wiki/Web_scraping")
