import os
from datetime import datetime

import cv2
import numpy as np
import pyautogui
from playsound import playsound
from rich.console import Console

if os.name == "nt":
    import ctypes

def log(name: str, event: str, passargs: str = False, style: str = "default", noprint: bool = False):
    """
    Logs an event into logs/log.log
    
    Args:
        name (str): The module name which this function is being called from.
        event (str): The event that has occurred with this module.
        passargs (str): Optional argument that can contain more infomation about the event. Defaults to False.
        style (str): Optional argument that can be used for rich text. Defaults to "default".
    """
    console = Console()
    print = console.print
    dt = datetime.now()
    dt = dt.strftime("%m/%d/%Y, %I:%M %p")
    if not os.path.isdir(resource_path("logs")):
        os.mkdir(resource_path("logs"))
    
    def write(file):
        if not os.path.isfile(resource_path(f"logs/{file}.log")):
            with open(resource_path(f"logs/{file}.log"), 'w') as f:
                f.write("Created log")
        
        if file == "log":
            with open(resource_path(f"logs/{file}.log"), 'a') as f:
                f.write("\n" + dt + ": " + name + " - " + event)
                if passargs:
                    f.write(passargs)
        else:
            with open(resource_path(f"logs/{file}.log"), 'a') as f:
                f.write("\n" + dt + ": " + event)
                if passargs:
                    f.write(passargs)
        if not noprint:
            if passargs:
                print(event + ", " + passargs, style=style)
            else:
                print(event, style=style)
        
    write("log")
    write(name[:-3])

def resource_path(relative_path: str, dir: str = os.path.expanduser('~') + "/Documents/JarvisProject") -> str:
    """
    Locate the file / folder in the Documents/JarvisProject Folder
    Args:
        relative_path (str): The file / folder to find
        dir (str, optional): The dir to find in
    Returns:
        (str): The location of the file / folder
    """
    if not os.path.isdir(dir):
        os.mkdir(dir)
    return dir + "/" + relative_path

def getscreenhight() -> int:
    """Gets the screen's hight. Defaults to 1920 if not Windows.
    
    Returns:
         int: Screen's hight.
    """
    if os.name == "nt":
        user32 = ctypes.windll.user32
        screensize = user32.GetSystemMetrics(1)
    else:
        screensize = 1920
    return int(screensize)

def getscreenwidth() -> int:
    """Gets the screen's width. Defaults to 1080 if not Windows.
    
    Return:
         int: Screen's width.
    """
    if os.name == "nt":
        user32 = ctypes.windll.user32
        screensize = user32.GetSystemMetrics(0)
    else:
        screensize = 1080
    return int(screensize)

def save(filename = "Recording", extention=".mp4"):
	i = 0
	while os.path.exists(filename + "%s" + extention % i):
		i += 1
	data = filename + "%s" + extention % i
	return data

def start(filename = "Recording0", extention=".mp4", fps = 60.0):
	resolution = (getscreenhight(), getscreenwidth()) # Defaults to screen res
	codec = cv2.VideoWriter_fourcc(*'MP4V')
	out = cv2.VideoWriter(save(filename, extention), codec, fps, resolution)
	cv2.namedWindow("Live", cv2.WINDOW_NORMAL)
	cv2.resizeWindow("Live", 480, 270)
	while True:
		img = pyautogui.screenshot()
		frame = np.array(img)
		frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
		out.write(frame)
		cv2.imshow('Live', frame)
		if cv2.waitKey(1) == ord('q'):
			break
	out.release()
	cv2.destroyAllWindows()
	return filename

if __name__ == "__main__":
	start()
else:
	log("screenrecord.py", "JarvisProject (/modules/screenrecord.py) was imported as a module")
