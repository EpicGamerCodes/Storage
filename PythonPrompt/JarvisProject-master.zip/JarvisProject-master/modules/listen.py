import json
import os
import re
import urllib.request

import pyautogui
import speech_recognition as sr
from playsound import playsound as ps
from gtts import gTTS

try:
    import modules.engine.offlinevoice as offlinevoice
    import modules.engine.playmusic as playmusic
    import modules.functions as functions
    import modules.gui as gui
    import modules.taskbar as taskbar
    import modules.screenrecord as screenrecord
    import modules.chat as chat
except ImportError:
    import engine.offlinevoice as offlinevoice
    import engine.playmusic as playmusic
    import functions as functions
    import gui as gui
    import taskbar as taskbar
    import screenrecord as screenrecord
    import chat as chat

class WrongCheckType(Exception):
    pass

def speak(text):
    if not functions.rconfig(name="no_voice"):
        functions.log("listen.py", "Voice is disabled", text)
        return "Voice is disabled"
    text = functions.remove_ansi_escape_seq(text)
    if not functions.internet():
        offlinevoice.speak(text)
        return
    text = str(text)
    tts = gTTS(text=text, lang='en')
    filename = functions.resource_path("voicefiles/speak.mp3")
    tts.save(filename)
    #sound = AudioSegment.from_file(filename)
    #so = sound.speedup(1.3, 150, 25)
    #so.export('voicefiles/speak.mp3', format = 'mp3')
    playsound(filename)
    os.remove(filename)

def playsound(filename):
    if not os.path.isfile(filename):
        ps(functions.resource_path(filename))
    else:
        ps(filename)

def say(text):
    speak(text)

def volumeset(vol):
    try:
        vol = int(vol)
    except:
        vol = functions.text2int(vol)
    for _ in range(50):
        pyautogui.press('volumedown')
    vol = int(vol) / 2
    vol = int(vol)
    volumeup(int(vol), through = False)

def volumeup(vol, half = True):
    try:
        vol = int(vol)
    except:
        vol = functions.text2int(vol)
    if half:
        vol = int(vol) / 2
        vol = int(vol)
    for _ in range(vol):
        pyautogui.press('volumeup')

def volumedown(vol, half = True):
    try:
        vol = int(vol)
    except:
        vol = functions.text2int(vol)
    if half:
        vol = int(vol) / 2
        vol = int(vol)
    for _ in range(vol):
        pyautogui.press('volumedown')

def joke():
    if not functions.internet():
        data = "No Internet"
        return data
    uf = urllib.request.urlopen("https://v2.jokeapi.dev/joke/Miscellaneous,Spooky,Christmas?blacklistFlags=nsfw,religious,political,racist,sexist,explicit&type=single")
    try:
        data = json.loads(uf.read().decode())
    except:
        data = {}
        data["joke"] = "Why is this joke so terrible? Because theres no internet!"
    return data["joke"]

class AddCommands:
    """
    To use:
        ac = AddCommands()
        ac.add(["example", "this"], lambda: print("hey"))
        ac.check(["running", "an", "example", "for", "this"]) # Runs the lambda
    """
    def __init__(self):
        self.run_commands = []

    def add(self, keywords: list, action, check_type: str = "in"):
        """Create commands with lambda actions.

        Args:
            keywords (list, str): List of keywords to start the action.
            action (lambda): The function or expression to run.
            check_type (str, optional): How to compare the speech and keywords ("and", "in", "equals"). Defaults to "in".
        """
        if type(keywords) is str:
            keywords = functions.strtolist(keywords)
        
        def create(lst: list):
            """Checks if lst matches keywords using the method given in check_type.
            Args:
                lst (list): The list to compare keywords with.

            Raises:
                WrongCheckType: Wrong check_type given.

            Returns:
                bool: True if action was executed, False is not.
            """
            if check_type == "in":
                for i in lst:
                    if i == keywords:
                        action()
                        return True
            elif check_type == "equals":
                if lst.sort() == keywords.sort():
                    action()
                    return True
            elif check_type == "and":
                if any(x in lst for x in keywords):
                    action()
                    return True
            else:
                raise WrongCheckType("Incorrect argument given.")

        self.run_commands.append(lambda lst: create(lst))
        self.run_commands[-1].__doc__ = create.__doc__
        self.run_commands[-1].__info__ = f"""Command keywords: {keywords}
Action: {action}
check_type: {check_type}"""
    
    def check(self, lst: list = False):
        """Check if self.audio is a keyword in lambda action"""
        if lst:
            for i in self.run_commands:
                found = i(lst)
        else:    
            for i in self.run_commands:
                found = i(self.lst)
        
        if found is True:
            return True
        else:
            return False

class Commands(AddCommands):
    def __init__(self):
        super().__init__()
        self.r = sr.Recognizer()
        self.add("say", lambda: speak(self.lst[4:]))
        self.add("joke", lambda: joke())
        self.add(["talk", "with", "you"], lambda: chat.Main("listen", speech=True, listen=True))
        self.add(["take", "screenshot"], lambda: speak("Saved Screenshot as: " + functions.screenshot()))
        self.add("add", lambda: gui.Help.help())
        self.add(["play", "music"], lambda: playmusic.start(), "and")
        self.add("time", lambda: speak("It is: " + functions.daytime()))

    def listen(self):
        with sr.Microphone() as source:
            print("Listening for Voice")
            self.audio = self.r.listen(source)
            try:
                if not functions.internet():
                    self.audio = self.r.recognize_sphinx(self.audio) # Offline
                self.audio = self.r.recognize_google(self.audio) # Online
                return True
            except:
                status = "No Speech"
                return status

    def commands(self):
        volumecheck = True
        #Convert the audio (as already text) to a list of words and if keywords in list (like "increase" and "volume") take the last word as the argument
        self.lst = functions.strtolist(self.audio)
        try:
            intvar = list(map(int, re.findall(r'\d+', self.audio)))
        except:
            intvar = False

        if (("increase" in self.lst) and ("volume" in self.lst)):
            print("Increasing Volume")
            if intvar:
                volumeup(intvar[0])
                speak("Increased Volume by: " + str(intvar[0]))
            else:
                volumeup(2)
                print(os.getcwd())
                playsound(functions.resource_path("voicefiles/increasevol.mp3"))
            volumecheck = False
            print("Increased Volume!")
        elif (("decrease" in self.lst) and ("volume" in self.lst)):
            if volumecheck:
                if intvar:
                    volumedown(intvar[0])
                    speak("Decreased Volume by: " + str(intvar[0]))
                else:
                    volumedown(2)
                    playsound("voicefiles/decreasevol.mp3")
            print("Decreased Volume!")
            volumecheck = False
        elif "volume" in self.lst:
            if volumecheck:
                volumeset(intvar[0])
                functions.log("listen.py", "Changed Volume to: " + str(intvar[0]))
                speak("Master Volume is now: " + str(intvar[0]))
        elif self.lst[:5] == "start":
            if os.path.isfile(os.getcwd() + '\\shortcuts\\' + self.lst[6:] + ".lnk"):
                os.system('start "" "' + os.getcwd() + '\\shortcuts\\' + self.lst[6:] + '.lnk"')
            elif not functions.isa():
                if os.path.isfile(os.getcwd() + '\\shortcuts\\aliases\\' + self.lst[6:] + ".lnk"):
                    os.system('start "" "' + os.getcwd() + '\\shortcuts\\aliases\\' + self.lst[6:] + '.lnk"')
            else:
                speak(self.lst[6:] + " is not a registered app!")
        elif "weather" in self.lst:
            w = functions.weather()
            speak("The current temperature is: " + str(w["hourly"]["temperature_2m"][-1]) + "°C, although it will feel like: " + str(w["hourly"]["apparent_temperature"][-1]) + "°C.")
            if w["hourly"]["precipitation"] == 0:
                speak("There is no expected rain at this hour.")
            else:
                speak("There is a " + w["hourly"]["precipitation"] + "%/ rain today.")
            if not w["hourly"]["snow_depth"] == 0:
                speak("There is a " + str(w["hourly"]["snow_depth"]) + " Snow Depth today.")
        elif (("screen" in self.lst) and ("record" in self.lst)):
            output = screenrecord.start()
            speak("Saved as: " + output)
        else:
            if not self.check():
                functions.log("listen.py", self.audio + " is not a recognised command!")
                speak(self.audio + " is not a recognised command!")

def start():
    listen = Commands()
    listen.listen()
    if not listen.audio == "No Speech":
        listen.commands()
    else:
        functions.log("listen.py", "No Voice Command Detected.")
        taskbar.notif("No Voice Command Detected")

if __name__ == "__main__":
    start()
else:
    functions.log("listen.py", "JarvisProject (/modules/listen.py) was imported as a module")
