import ntpath
import os
from datetime import datetime

from playsound import playsound
from rich.console import Console

def log(name: str, event: str, passargs: str = False, style: str = "default", noprint: bool = False):
    """
    Logs an event into logs/log.log
    
    Args:
        name (str): The module name which this function is being called from.
        event (str): The event that has occurred with this module.
        passargs (str): Optional argument that can contain more infomation about the event. Defaults to False.
        style (str): Optional argument that can be used for rich text. Defaults to "default".
    """
    console = Console()
    print = console.print
    dt = datetime.now()
    dt = dt.strftime("%m/%d/%Y, %I:%M %p")
    if not os.path.isdir(resource_path("logs")):
        os.mkdir(resource_path("logs"))
    
    def write(file):
        if not os.path.isfile(resource_path(f"logs/{file}.log")):
            with open(resource_path(f"logs/{file}.log"), 'w') as f:
                f.write("Created log")
        
        if file == "log":
            with open(resource_path(f"logs/{file}.log"), 'a') as f:
                f.write("\n" + dt + ": " + name + " - " + event)
                if passargs:
                    f.write(passargs)
        else:
            with open(resource_path(f"logs/{file}.log"), 'a') as f:
                f.write("\n" + dt + ": " + event)
                if passargs:
                    f.write(passargs)
        if not noprint:
            if passargs:
                print(event + ", " + passargs, style=style)
            else:
                print(event, style=style)
        
    write("log")
    write(name[:-3])

def resource_path(relative_path: str, dir: str = os.path.expanduser('~') + "/Documents/JarvisProject") -> str:
    """
    Locate the file / folder in the Documents/JarvisProject Folder
    Args:
        relative_path (str): The file / folder to find
        dir (str, optional): The dir to find in
    Returns:
        (str): The location of the file / folder
    """
    if not os.path.isdir(dir):
        os.mkdir(dir)
    return dir + "/" + relative_path

def path_leaf(path):
    head, tail = ntpath.split(path)
    return tail or ntpath.basename(head)

def find(folder = str(os.environ['USERPROFILE'] + "/Music")):
    filepath = []
    for path, _, files in os.walk(folder):
        filepath.extend([os.path.join(path, file).replace('\\', '/') for file in files
                         if str(file).endswith('.mp3')])
    return filepath

def start(type = "all", file = None, folder = "Music", fullfolder = False):
    if not fullfolder:
        userfolder = str(os.environ['USERPROFILE'] + "/")
        musicfolder = userfolder + folder
    else:
        musicfolder = fullfolder
    print(musicfolder)
    musicfiles = find(musicfolder)
    musicfiles = [path_leaf(path) for path in musicfiles]
    print(musicfiles)
    if type == "all":
        for i in range(len(musicfiles)):
            playsound(i)
    if type == "all-loop":
        for i in range(len(musicfiles)):
            playsound(i)
    elif type == "single":
        for i in range(len(musicfiles)):
            if i == file:
                print("Playing: " + i)
                playsound(i)
            else:
                print("File not found!")
    elif type == "single-loop":
        for i in range(len(musicfiles)):
            if i == file:
                while True:
                    playsound(i)

if __name__ == "__main__":
    file = input("File name: ")
    start(type = "single", file=file)
else:
    log("playmusic.py","JarvisProject (/engine/playmusic.py) was imported as a module")
