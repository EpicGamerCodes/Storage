# What is this folder?

This folder contains modules that do not interact with the user and is imported by the modules in the 'modules' folder. These scripts are called engines as they contain critical files for proper usage.
