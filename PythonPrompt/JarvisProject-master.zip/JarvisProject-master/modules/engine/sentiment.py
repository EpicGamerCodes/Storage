from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer

class NoText(Exception):
	pass

def main(sentence: str, both: bool = False, number: bool = False, store = False):
    if sentence == "":
        raise NoText("No text was given!")
    sia = SentimentIntensityAnalyzer()
    score = sia.polarity_scores(sentence)["compound"]
    
    def put(sc: str):
        if both:
            store["return"] = sc, score
        else:
            store["return"] = sc

    if not store is False:
        if number:
            store["return"] = score
        if score == 0:
            put("neutral")
        elif score > 0:
            put("positive")
        else:
            put("negative")
    else:
        if both:
            if score == 0:
                return "neutral", score
            elif score > 0:
                return "positive", score
            else:
                return "negative", score
        else:
            if number:
                return score
            if score == 0:
                return "neutral"
            elif score > 0:
                return "positive"
            else:
                return "negative"

def check(sentence: str, both: bool = False, number: bool = False, store = False):
    return main(sentence, both, number, store)

def start():
    print("Import main() from this file and use it like:\nmain('Hello!') - Returns positive")
    text = input("Text to check: ")
    print(main(text))

if __name__ == "__main__":
	start()
else:
	print("engine/sentiment.py", "JarvisProject (engine/sentiment.py) was imported as a module")