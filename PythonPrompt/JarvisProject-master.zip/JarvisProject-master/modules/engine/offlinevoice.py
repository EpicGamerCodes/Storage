import os
from rich.console import Console
from datetime import datetime
import re

import pyttsx3

def log(name: str, event: str, passargs: str = False, style: str = "default", noprint: bool = False):
    """
    Logs an event into logs/log.log
    
    Args:
        name (str): The module name which this function is being called from.
        event (str): The event that has occurred with this module.
        passargs (str): Optional argument that can contain more infomation about the event. Defaults to False.
        style (str): Optional argument that can be used for rich text. Defaults to "default".
    """
    console = Console()
    print = console.print
    dt = datetime.now()
    dt = dt.strftime("%m/%d/%Y, %I:%M %p")
    if not os.path.isdir(resource_path("logs")):
        os.mkdir(resource_path("logs"))
    
    def write(file):
        if not os.path.isfile(resource_path(f"logs/{file}.log")):
            with open(resource_path(f"logs/{file}.log"), 'w') as f:
                f.write("Created log")
        
        if file == "log":
            with open(resource_path(f"logs/{file}.log"), 'a') as f:
                f.write("\n" + dt + ": " + name + " - " + event)
                if passargs:
                    f.write(passargs)
        else:
            with open(resource_path(f"logs/{file}.log"), 'a') as f:
                f.write("\n" + dt + ": " + event)
                if passargs:
                    f.write(passargs)
        if not noprint:
            if passargs:
                print(event + ", " + passargs, style=style)
            else:
                print(event, style=style)
        
    write("log")
    write(name[:-3])

def remove_ansi_escape_seq(text: str) -> str:
    """Removes ANSI escape sequences (such as a colorama color
    code) from a string so that they aren't spoken.

    Args:
        text (str): The text that may contain ANSI escape sequences.

    Returns:
        str: The text with ANSI escape sequences removed.
    """
    text = re.sub(r'''(\x9B|\x1B\[)[0-?]*[ -\/]*[@-~]''', '', text)
    return text

def speak(text, rate = 125):
    text = remove_ansi_escape_seq(text)
    engine = pyttsx3.init()
    rate = engine.getProperty('rate')
    engine.setProperty('rate', rate)
    engine.say(text)
    engine.runAndWait()
    engine.stop()
    engine = None

def resource_path(relative_path: str, dir: str = os.path.expanduser('~') + "/Documents/JarvisProject") -> str:
    """
    Locate the file / folder in the Documents/JarvisProject Folder
    Args:
        relative_path (str): The file / folder to find
        dir (str, optional): The dir to find in
    Returns:
        (str): The location of the file / folder
    """
    if not os.path.isdir(dir):
        os.mkdir(dir)
    return dir + "/" + relative_path

def say(text, rate = 125):
    speak(text, rate)

def start():
    print("Import speak() from this file and use it like:\nspeak('Text to speak', rate).\nrate = The speed of which the voice should be. Defaults to 125")
    while True:
        os.system("cls||clear")
        text = input("Text to say: ")
        speak(text)

if __name__ == "__main__":
	start()
else:
	log("offlinevoice.py", "JarvisProject (/engine/offlinevoice.py) was imported as a module")
