import tkinter as tk
from threading import Thread
from tkinter import *

import pystray
from mss import mss
from PIL import Image
from pystray import Icon as icon
from pystray import Menu as menu
from pystray import MenuItem as item

try:
    import modules.functions as functions
    import modules.gui as gui
    import modules.listen as listen
except Exception:
    import functions
    import listen
    import gui

import time

start_time = None

def action():
    pass

def prepruncode():
    functions.log("taskbar.py", "Asking for code to run")
    first = tk.Tk()
    tk.Label(first, text="Code to Run: ").grid(row=0)
    e = tk.Entry(first)
    e.grid(row=0, column=1)
    first.mainloop()
    output = functions.runcode(e)
    show(output)

def show(output):
    root = tk()
    root.geometry("250x170")
    T = Text(root, height = 5, width = 52)
    l = Label(root, text = "Fact of the Day")
    l.config(font =("Courier", 14))
    b1 = Button(root, text = "Close",
                command = root.destroy) 
    l.pack()
    T.pack()
    b1.pack()
    T.insert(tk.END, output)
    tk.mainloop()

def time_convert(sec):
  mins = sec // 60
  sec = sec % 60
  hours = mins // 60
  mins = mins % 60
  data = "Time Lapsed = {0}:{1}:{2}".format(int(hours),int(mins),sec)
  return data

def starttimer():
    global start_time
    start_time = str(time.time())

def converse():
    window = gui.AI_GUI(debug=False)
    window.launch()

def endtime():
    st = start_time
    if st is None:
        listen.speak("You have not started the timer")
        return
    else:
        st = float(st)
    endtime = time.time()
    time_lapsed = endtime - st
    listen.speak(str(time_convert(time_lapsed)))
    st = None
    endtime = None
    time_lapsed = None

class SystemTray:
    def __init__(self):
        image = Image.open("icon.png")
        system_menu = (
            item("Start Chat Engine (AI)", lambda: converse()),
            item('Take Screen Shot', lambda: functions.screenshot()),
            item('Listen for Voice Command', lambda: listen.start()),
            item('Run Code', lambda: prepruncode()),
            item('Stopwatch', menu(
                item('Start', lambda: starttimer()),
                item('End', lambda: endtime())
                ))
            )
        self.icon = pystray.Icon("JarvisProject", image, "JarvisProject", system_menu)
    
    def notif(self, text: str, title: str, timeout: int = 5):
        self.icon.notify(text, title)
        time.sleep(timeout)
        self.icon.remove_notification()
    
    def launch(self, detached: bool = False):
        if detached:
            self.icon.run_detached()
        else:
            self.icon.run()

def notif(text: str, title: str, tray: SystemTray = SystemTray(), timeout: int = 5):
        tray.icon.notify(text, title)
        time.sleep(timeout)
        tray.icon.remove_notification()

def start(tray: SystemTray = SystemTray()):
    if not functions.rconfig(name="no_tray"):
        functions.log("taskbar.py", "System Tray has been disabled.")
    else:
        tray.launch(True)
        tray.notif("Hey", "Title")

if __name__ == "__main__":
    start()
else:
    functions.log("taskbar.py","JarvisProject (/modules/taskbar.py) was imported as a module")
