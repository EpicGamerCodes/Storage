import argparse
import lzma
import multiprocessing
import os
import pickle
import re
import shutil
import sys
import time
from dataclasses import dataclass, field
from datetime import datetime
from threading import Thread as th

import playsound
import speech_recognition as sr
import torch
from gtts import gTTS
from loguru import logger
from matplotlib import pyplot as plt
from pick import pick
from rich.console import Console
from transformers import AutoModelForCausalLM, AutoTokenizer
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer

exit_session = lambda: exit()
logger.add(os.path.expanduser("~") + "/Documents/JarvisProject/logs/debug/" + os.path.split(__file__)[1][:-3] + ".log", retention="10 days", backtrace=True, diagnose=True)

class NoText(Exception):
    pass

@logger.catch
def Thread(target, args: tuple = (), join: bool = False):
    """Create a threading.Thread instance.

    Args:
        target (function): Function to run.
        args (tuple, optional): Arguments to pass to the function. Defaults to ().
        join (bool, optional): Wait for thread to complete. Defaults to False.
    """
    thread = th(target=target, args=args)
    thread.start()
    logger.debug(f"Created Thread with target: {target}")
    if join:
        thread.join()

@logger.catch
def thread(target, args: tuple = (), ret: bool = False, join: bool = False):
    """Create a multiprocessing.Thread instance

    Args:
        target (function): Function to run.
        args (tuple, optional): Arguments to pass to the function. Defaults to ().
        ret (bool, optional): Return data from function using multiprocessing.Manager(). Defaults to False.
        join (bool, optional): Wait for thread to complete. Defaults to False.
    """
    if ret:
        join = True
        manager = multiprocessing.Manager()
        return_dict = manager.dict()
        args = args + (return_dict,)
    
    p = multiprocessing.Process(target=target, args=args)
    p.start()
    logger.debug(f"Created Multiprocess with target: {target}")
    if join:
        p.join()
    if ret:
        return return_dict.values()[0]

@logger.catch
def resource_path(relative_path: str, dir: str = os.path.expanduser('~') + "/Documents/JarvisProject") -> str:
    """
    Locate the file / folder in the Documents/JarvisProject Folder
    Args:
        relative_path (str): The file / folder to find
        dir (str, optional): The dir to find in
    Returns:
        (str): The location of the file / folder
    """
    if not os.path.isdir(dir):
        os.mkdir(dir)
    return dir + "/" + relative_path

@logger.catch
def log(event: str, passargs: str = False, style: str = "default", noprint: bool = False):
    """
    Logs an event into logs/log.log
    
    Args:
        event (str): The event that has occurred with this module.
        passargs (str): Optional argument that can contain more infomation about the event. Defaults to False.
        style (str): Optional argument that can be used for rich text. Defaults to False.
    """
    console = Console()
    print = console.print
    name = "chat"
    dt = datetime.now()
    dt = dt.strftime("%m/%d/%Y, %I:%M %p")
    if not os.path.isdir(resource_path("logs")):
        os.mkdir(resource_path("logs"))
    
    def write(file):
        if not os.path.isfile(resource_path(f"logs/{file}.log")):
            with open(resource_path(f"logs/{file}.log"), 'w') as f:
                f.write("Created log")
        
        with open(resource_path(f"logs/{file}.log"), 'a') as f:
            f.write("\n" + dt + ": " + event)
            if passargs:
                f.write(passargs)
    if not noprint:
        if passargs:
            print(event + ", " + passargs, style=style)
        else:
            print(event, style=style)
        
    write("log")
    write(name[:-3])

@logger.catch
def chkargs(argv: str = sys.argv):
    """Processes a string passed as a CLI Argument.
    
    Args:
        argv (str): A string to be treated as a CLI Argument. (Defaults to 'sys.argv')
    """
    parser = argparse.ArgumentParser()
    parser.add_argument("--profile", nargs='*', action='store', help='Use a profile command')

    try:
        args=parser.parse_args(argv)
    except:
        return

    if args.profile is not None and len(args.profile) not in (0, 2):
        parser.error('Either give no values for profile, or two, not {}.'.format(len(args.profile)))

    log("Profile Arg: " + str(args.profile), noprint=True)
    
    if args.profile[0] == "make":
        pname = args.profile[1]
        if pname == "FastBoot":
            create_fastboot()
            exit(False)

        talk = Main(name=pname, bypass=True)
        talk.savemodel()
    
    if args.profile[0] == "delete":
        pname = args.profile[1]
        log("Deleting Profile: " + pname + "...", style="blink bold red")
        shutil.rmtree(os.path.expanduser('~') + "/Documents/JarvisProject/profiles/" + pname)
        log("Profile Successfully Deleted!", style="bold green")
        
    if args.profile[0] == "rename":
        plist = re.sub("[^\w]", " ",  args.profile).split()
        path = os.path.expanduser('~') + "/Documents/JarvisProject/profiles/"
        try:
            pcname = plist[1]
        except Exception:
            log("You need to provide the current profile name!")
            exit(False)
        try:
            pnname = plist[2]
        except Exception:
            parser.error("You need to provide the new profile name!")
            exit(False)
        os.rename(path + pcname, path + pnname)
        log("Profile '" + pcname + "' has been successfully renamed to: '" + pnname + "'", style="bold green")

@logger.catch
def inputl(event: str = "Unknown Input") -> str:
    """Logs the input

    Args:
        event (str, optional): The prompt for the input. Defaults to "Unknown Input".

    Returns:
        str: The string that the user entered.
    """
    var = input(event)
    log(event + var, noprint=True)
    return var

def cls(bypass: bool = False):
    """Deletes last line in the console"""
    if bypass:
        return
    print("\033[A       \033[A")

def exit(ask: bool = True):
    """Stops the script."""
    if ask:
        input("\nPress anything to exit")
    exit_session()

@logger.catch
def say(text: str):
    """Output audio data as speech using gTTS.

    Args:
        text (str): Text to say
    """
    try:
        tts = gTTS(text=text, lang='en')
    except AssertionError:
        tts = gTTS(text="I no longer wish to speech to you.", lang='en')
        notalk = True
    filename = os.path.expanduser('~') + "/Documents/JarvisProject/voicefiles/speech.mp3"
    tts.save(filename)
    playsound.playsound(filename)
    os.remove(filename)

@logger.catch
def create_fastboot(overwrite: bool = False):
    """Create a 'FastBoot' profile.

    Args:
        overwrite (bool, optional): Overwrite existing profile if already exists. Defaults to False.
    """
    log("Creating Profile...", style="blink")
    model_name = "microsoft/DialoGPT-large"
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    model = AutoModelForCausalLM.from_pretrained(model_name)
    npath = os.path.expanduser('~') + "/Documents/JarvisProject/profiles/FastBoot"
    try:
        try:
            os.mkdir(os.path.expanduser('~') + "/Documents/JarvisProject/profiles")
        except Exception:
            pass
        os.mkdir(npath)
    except Exception:
        if not overwrite:
            log("Profile already exists!", style="bold red")
            return
    
    os.mkdir(npath + "/model")
    tokenizer.save_pretrained(npath + "/tokenizer/")
    torch.save(model, npath + "/model/mind.pt")
    cls()
    log("Profile created!", style="bold green")
    log("Finishing up...")
    log("Deleting cached model...", noprint=True)
    shutil.rmtree(os.path.expanduser('~') + "/.cache/huggingface")

class Restore:
    @logger.catch
    def save(file: str, path: str = os.path.expanduser('~') + "/Documents/JarvisProject/profiles/Restore/", data = None, compress: bool = False):
        if not os.path.isdir(path):
            os.mkdir(path)

        if data is None:
            raise TypeError("Give a chat.Main class type!")

        if compress:
            with lzma.open(path + file, "wb") as f:
                pickle.dump(data, f)
            log(f"{data} saved with lzma compression.")
        else:
            with open(path + file, "wb") as f:
                pickle.dump(data, f)
            log(f"{data} saved.")
    
    @logger.catch
    def load(file: str, path: str = os.path.expanduser('~') + "/Documents/JarvisProject/profiles/Restore/", compressed: bool = False):
        if compressed:
            with lzma.open(path + file, "rb") as f:
                ai = pickle.load(f)
            return ai
        else:
            with open(path + file, "rb") as f:
                ai = pickle.load(f)
            return ai        

class Profile:
    """Contains functions for loading and saving profile"""
    @logger.catch
    def loadmodel(self, path: str) -> list:
        """Load saved variables from a profile.

        Args:
            path (str, optional): Path to save in.

        Returns:
            list: Saved variables.
        """
        try:
            log("Loading saved variables...", noprint=True)
            with open(path + "/variables.pkl", "rb") as f:
                self.input_ids, self.bot_input_ids, self.chat_history_ids, self.steps, self.data = pickle.load(f)
            log("Successfully loaded saved variables!", noprint=True)
        except Exception as e:
            log("Error loading saved variables: " + str(e), style="bold red")
            exit()
    
    @logger.catch
    def pickmind(self, path: str = os.path.expanduser('~') + "/Documents/JarvisProject/profiles") -> list:
        """Pick a profile from saved variables.

        Args:
            path (str, optional): Path to save in. Defaults to os.path.expanduser('~')+"/Documents/JarvisProject/profiles".

        Returns:
            list: Saved variables.
        """
        log("Reading models...", style="blink")
        os.system("cls||clear")
        mindpath = path + "/profiles"
        subfolders = [f.path for f in os.scandir(mindpath) if f.is_dir()]
        options = []

        try:
            subfolders[0]
        except Exception:
            log("No saved models exist. Please restart JarvisProject to continue.", style="bold red")
            os.rmdir(path + "/profiles")
            exit()

        for i in range(len(subfolders)):
            options.append(os.path.basename(os.path.normpath(subfolders[i])))

        if "FastBoot" in options:
            options.remove("FastBoot")
        option, index = pick(options, title="Which saved profile do you want to load: ", indicator='=>')
        log("User picked: " + option + ", index: "  + str(index), noprint=True)
        self.loadmodel(mindpath + "/" + option)
    
    @logger.catch
    def savemodel(self, name: str = "Unnamed", path: str = os.path.expanduser('~') + "/Documents/JarvisProject/profiles", overwrite: bool = False):
        """Save core and log variables.

        Args:
            name (str, optional): Name to give to saved folder. Defaults to "Unnamed".
            path (str, optional): Path to save in. Defaults to os.path.expanduser('~')+"/Documents/JarvisProject/profiles".
            overwrite (bool, optional): Overwrite existing profile if already exists. Defaults to False.
        """
        if not name == "Unnamed":
            self.name = name
        
        npath = path + "/" + self.name
        log("Saving profile in: " + npath + "...", style="blink")
        if not os.path.isdir(path + "/profiles"):
            os.mkdir(path + "/profiles")
        
        try:
            os.mkdir(npath)
        except Exception:
            if not overwrite:
                log("Profile already exists!", style="bold red")
                return

        try:
            log("Saving variables...", noprint=True)
            with open(npath + "/variables.pkl", "wb+") as f:
                pickle.dump([self.input_ids, self.bot_input_ids, self.chat_history_ids, self.steps, self.data], f)
            log("Successfully Saved variables!", noprint=True)
            log("Profile Saved!", style="bold green")
        except Exception as e:
            log("Error saving variables: " + str(e), style="bold red")

class Chart(Profile):
    
    @logger.catch
    def emcreate(self, save: str = False, dpi: int = 150):
        """Create a chart based on JarvisProject's emotions using Data.emotions.

        Args:
            save (str, optional): Save the file, supplying the path. Defaults to False.
            dpi (int, optional): DPI of Chart Image. Defaults to 150.
        """
        emotions = sorted(self.data.emotions.items())
        usremotions = sorted(self.data.usremotions.items())
        x, y = zip(*emotions)
        
        plt.style.use('Solarize_Light2')
        plt.title("JarvisProject Emotions")
        plt.xlabel("Time")
        plt.ylabel("Emotions")
        plt.plot(x,y, color="blue", marker="o", label="JarvisProject")
        x, y = zip(*usremotions)
        plt.plot(x,y, color="red", marker="o", label="User")
        plt.legend()
        plt.grid(True)
        plt.xticks(rotation=45, ha='right')
        plt.tight_layout()
        if save:
            plt.savefig(save, bbox_inches='tight', dpi=dpi)
            plt.close()
            return
        plt.show()
        plt.close()
    
    @logger.catch
    def loadandshow(self, path: str):
        """Load profile and show Chart.

        Args:
            path (str, optional): Path where the pickle file is stored.
        """
        self.loadmodel(path)
        Chart.emcreate()

@dataclass
class Data:
    """This class stores data for other classes to use."""
    usrrequest: list = field(default_factory=lambda: [])
    responce: list = field(default_factory=lambda: [])
    emotions: dict = field(default_factory=lambda: {})
    usremotions: dict = field(default_factory=lambda: {})

class Load:
    "This class contains all the loading functions for the Main Class"
    
    @logger.catch
    def __init__(self, name: str, no: int = 100, speech = "both", bypass: bool = False, listen: bool = False, temperature: float = 0.75, debug: bool = False):
        """The main function for the AI, sets all the variables needed and checks if all the files / folders exist to run.

        Args:
            name (str): A name for the instance for Main.name_of_instances to store.
            no (int, optional): How many times to converse with the AI. Defaults to Infinity.
            speech (str, optional): What output mode to use. True only speaks the output, False only displays the output and "both" speaks and displays the output. Defaults to "both".
            bypass (bool, optional): This displays no text on the screen and skips all user inputs. If the 'no' variable is set to 100, 'no' automatically gets set to 0, also disabling user input for JarvisProject to give an output to. Defaults to False.
            listen (bool, optional): If enabled, the microphone will be used as user input for JarvisProject to give an output to. Defaults to False.
            temperature (float, optional): Increase to let the AI create paragraphs of text, or use a low number to let it speech in short sentences. Defaults to 0.75.
            debug (bool, optional): Force show all logging.
        """
        log = self.log
        self.name = str(name) # In case the name is an int
        self.speech = speech
        self.bypass = bypass
        self.listen = listen
        self.loadm = False
        self.emcheck = False
        self.ret = False
        self.no = no
        self.step = 0
        self.temperature = temperature
        self.debug = debug
        self.output = None
        self.data = Data()
        
        if self.bypass:
            if self.no == 100:
                self.step = 0
                self.no = 0

        log("Loading...", style="blink bold green")
        log("startchecks in progress...", noprint=True)
        self.startchecks()
        log("checkfastboot in progress...", noprint=True)
        self.checkfastboot()
        log("usrprefer in progress...", noprint=True)
        self.usrprefer()

        if not self.loadm:
            log("Model not loaded, loading model now...", noprint=True)
            model_name = "microsoft/DialoGPT-large"
            self.tokenizer = AutoTokenizer.from_pretrained(model_name)
            log("Tokenizer Load complete!", noprint=True)
            self.model = AutoModelForCausalLM.from_pretrained(model_name)
            log("Model Load complete!", noprint=True)
        
        cls(self.bypass)
        log("Loading Complete!", style="bold green")
    
    @logger.catch
    def startchecks(self, dir: str = os.path.expanduser('~') + "/Documents/JarvisProject"):
        """Checks for all files and folders and checks if fastboot needs to be made.

        Args:
            dir (str, optional): _description_. Defaults to os.path.expanduser('~')+"/Documents/JarvisProject".
        """
        log = self.log
        fastboot = False
        if not os.path.isdir(dir):
            os.mkdir(dir)
            fastboot = True

        if not os.path.isdir(dir + "/logs"):
            os.mkdir(dir + "/logs")
            log("Directory " + dir + "/logs " + " Created", noprint=True) 

        if not os.path.isdir(dir + "/voicefiles"):
            os.mkdir(dir + "/voicefiles")
            log("Directory " + dir + "/voicefiles " +  " Created", noprint=True)

        if os.path.isfile(os.path.expanduser('~') + "/Documents/JarvisProject/logs/chatengine.log"):
            with open(os.path.expanduser('~') + "/Documents/JarvisProject/logs/chatengine.log", "a") as f:
                f.write("\n\n-------- New Session --------\n")
            log("Directory " + dir +  " already exists", noprint=True)
        self.fastboot = fastboot
    
    def log(self, event: str = "Unknown Event", passargs: str = False, noprint: bool = False, style: str = "default"):
        """Redirects to log()

        Args:
            event (str, optional): The event that occurred. Defaults to "Unknown Event".
            passargs (str, optional): Any extra infomation. Defaults to False.
            noprint (bool, optional): If the event and passargs should be printed. Defaults to False.
            style (str, optional): To be used with rich.Console. Defaults to False.
        """
        if ((self.bypass is True) or (self.debug is True)):
            log(event=event, passargs=passargs, noprint=True, style=style)
        else:
            log(event=event, passargs=passargs, noprint=noprint, style=style)
    
    @logger.catch
    def checkfastboot(self):
        """Check if fastboot exists and load else ask user if they want to create it."""
        log = self.log
        fastboot = None
        if not os.path.isdir(os.path.expanduser('~') + "/Documents/JarvisProject/profiles/FastBoot"):
            self.fastboot = True
        else:
            self.fastboot = False
        
        fastbootpath = os.path.expanduser('~') + "/Documents/JarvisProject/profiles"

        if self.fastboot:
            while not ((fastboot == "Y") or (fastboot == "N")):
                log("Would you like to create a FastBoot profile for JarvisProject? This enables instant loading times and the profile is always fresh. (Space Required: 3GB)")
                fastboot = inputl("(Y/N): ")
            if fastboot == "Y":
                create_fastboot()
                log("Unless more profiles are created, this will be the default.")
                self.tokenizer = AutoTokenizer.from_pretrained(fastbootpath + "/FastBoot/tokenizer/")
                self.model = torch.load(fastbootpath + "/FastBoot/model/mind.pt")
                self.model.eval()
                self.loadm = True
                self.fastboot = True
            
            if fastboot == "N":
                self.fastboot = False
        else:
            self.tokenizer = AutoTokenizer.from_pretrained(fastbootpath + "/FastBoot/tokenizer/")
            self.model = torch.load(fastbootpath + "/FastBoot/model/mind.pt")
            self.model.eval()
            log("Loaded FastBoot")
            self.loadm = True
    
    @logger.catch
    def usrprefer(self):
        """Checks for user preferences (voice, load saved profile) and then Displays user preferences"""
        log = self.log
        load = False
        if not self.bypass:
            if not self.listen:
                while not ((self.listen == "Y") or (self.listen == "N")):
                    self.listen = inputl("Would you like to speech JarvisProject using your voice? (Y/N): ")
                if self.listen == "Y":
                    self.listen = True
                if self.listen == "N":
                    self.listen = False

            if os.path.isdir(os.path.expanduser('~') + "/Documents/JarvisProject/profiles/" + self.name): # If name is a saved profile name, load the profile
                load = True
                if not self.name == "FastBoot":
                    self.loadmodel(os.path.expanduser('~') + "/Documents/JarvisProject/profiles/" + self.name)
            if not load:
                load = False
                while not ((load == "Y") or (load == "N")):
                    load = inputl("Would you like to load a saved JarvisProject profile? (Y/N): ")
                if load == "Y":
                    self.pickmind()
                    load = True
                if load == "N":
                    pass
                
        if self.speech == "both":
            log("Speak and Console mode.")
        elif self.speech:
            Thread(target= lambda: say("Speak mode"))
        else:
            log("Console mode")

        if not self.listen:
            log("Input 'exit' to stop talking to JarvisProject.")
            log("Loading...", style="blink green")
        else:
            Thread(target= lambda: say("Input 'exit' to stop talking to JarvisProject."))
            Thread(target= lambda: say("Loading..."))
    
    @logger.catch
    def info(self):
        """Show instance infomation."""
        log(f"Instance Name: {self.name}")
        log(f"Speak Mode:  {self.speech}")
        log(f"Bypass Mode: {self.bypass}")
        log(f"Listen Mode: {self.listen}")
        log(f"Return Mode: {self.ret}")
        log(f"self.talk() has been called: {self.step} times.")
        log((f"Allowed converse times: ") + ("Infinity" if self.no == float("inf") else f"{self.no}"))
        log(("Model and Tokenizer Loaded" if self.loadm else "Model and Tokenizer not loaded!") + f" ({self.loadm})")
        print("\n")
        log(f"no_of_instances: {Main.no_of_instances}")
        log(f"name_of_instances: {Main.name_of_instances}")

class Main(Load, Chart):
    """
    The Core AI module.

    There are 2 variables:
        no_of_instances (int): Tracks the number of instances made
        name_of_instances (list): Tracks the name of the instaces made
    """
    no_of_instances = 0
    name_of_instances = []

    @logger.catch
    def __init__(self, name: str, no: int = float("inf"), speech = "both", bypass: bool = False, listen: bool = False, temperature: float = 0.75, debug: bool = False):
        """The main function for the AI, sets all the variables needed and checks if all the files / folders exist to run.

        Args:
            name (str): A name for the instance for Main.name_of_instances to store.
            no (int, optional): How many times to converse with the AI. Defaults to Infinity.
            speech (str, optional): What output mode to use. True only speaks the output, False only displays the output and "both" speaks and displays the output. Defaults to "both".
            bypass (bool, optional): This displays no text on the screen and skips all user inputs. If the 'no' variable is set to 100, 'no' automatically gets set to 0, also disabling user input for JarvisProject to give an output to. Defaults to False.
            listen (bool, optional): If enabled, the microphone will be used as user input for JarvisProject to give an output to.. Defaults to False.
            debug (bool, optional): Force show all logging.
        """
        super().__init__(name, no, speech, bypass, listen)
        Main.no_of_instances = +1
        Main.name_of_instances.append(self.name)
    
        if not self.bypass:
            for self.step in range(no): # Repeats loop until broken or 100 'steps' are taken.
                if not self.listen:
                    self.text = inputl(">> You: ")
                    while self.text == "":
                        cls(self.bypass)
                        self.text = inputl(">> You: ")
                    self.talk()
                    self.checktalk()

                    # Print output from the AI
                    if self.speech == "both":
                        log(f"JarvisProject: {self.output}")
                        Thread(target=lambda: say(self.output))
                    elif self.speech:
                        Thread(target=lambda: say(self.output))
                    else:
                        log(f"JarvisProject: {self.output}")

                    self.exit = self.checktalk(bye=True)
                    if self.exit:
                        break
                    
                    if self.text == "exit":
                        break
                else:
                    if self.listen:
                        input("Press 'Enter' to start listening...")
                        print("\033[A                                     \033[A")
                    self.text = self.listenvoice()
                    log(f">> You:  {self.text}")
                    self.talk()
                    Thread(target=lambda: say(self.output))
                    log(f"JarvisProject: {self.output}")
                    self.checktalk()
                    self.exit = self.checktalk(bye=True)
                    if self.exit:
                        break
                    
            self.save()
    
    @logger.catch
    def talk(self, text: str = False, temperature: float = False):
        """The core AI module, this generates the output based on the input given.

        Args:
            text (str, optional): If called, this needs to be supplied, this variable gets saved into self.text . Defaults to False.

        Returns:
            str: If self.ret is True, this function saves its output as self.output and returns it's output. 
        """
        if self.step >= self.no:
            self.output = "self.step is equal or greater than Allowed converse times (self.no). Increase this to continue."
            logger.warning(self.output)
            return self.output

        if text:
            self.text = text
        
        if temperature:
            self.temperature = temperature
        
        if self.step == 0:
            self.input_ids = self.tokenizer.encode(self.text + self.tokenizer.eos_token, return_tensors="pt")

        self.bot_input_ids = torch.cat([self.chat_history_ids, self.input_ids], dim=-1) if self.step > 0 else self.input_ids
        self.chat_history_ids = self.model.generate(self.bot_input_ids, max_length=1000, do_sample=True, top_p=0.95, top_k=0, temperature=self.temperature, pad_token_id=self.tokenizer.eos_token_id)
        
        self.output = self.tokenizer.decode(self.chat_history_ids[:, self.bot_input_ids.shape[-1]:][0], skip_special_tokens=True)
        self.outputlist = re.sub("[^\w]", " ", self.output).split()
        self.data.responce.append(self.output)
        self.data.usrrequest.append(self.text)
        self.step =+ 1
        if self.ret:
            return self.output
    
    @logger.catch
    def checktalk(self, bye: bool = False, threading: bool = False):
        """Check AI's output sentiment and check if the AI does not want to talk with the User anymore

        Args:
            bye (bool, optional): Checks if the AI no longer wishes to speech with the user. Defaults to False.

        Returns:
            bool: If bye is True, It returns True / False, No longer want to speech / Still wants to speech
        """
        log = self.log
        crtime = time.strftime("%H:%M:%S")

        if not bye:
            if not self.emcheck:
                if threading:
                    self.sentimentv, self.data.emotions[crtime] = thread(target=Main.sentiment, args=(self.output, True, False), ret=True)
                    self.data.usremotions[crtime] = thread(target=Main.sentiment, args=(self.text, False, True), ret=True, join=False)
                else:
                    self.sentimentv, self.data.emotions[crtime] = Main.sentiment(self.output, both = True)
                    self.data.usremotions[crtime] = Main.sentiment(self.text, number=True)
                if not self.bypass:
                    os.system("cls||clear")
                log(f"[JarvisProject is currently feeling: {self.sentimentv}]", style="bold white")
                log(">> You: " + self.text)
                self.emcheck = True
                self.crfeeling = self.sentimentv
            else:
                # Get current feeling
                if threading:
                    self.sentimentv, self.data.emotions[crtime] = thread(target=Main.sentiment, args=(self.output, True, False), ret=True)
                    self.data.usremotions[crtime] = thread(target=Main.sentiment, args=(self.text, False, True), ret=True)
                else:
                    self.sentimentv, self.data.emotions[crtime] = Main.sentiment(self.output, both = True)
                    self.data.usremotions[crtime] = Main.sentiment(self.text, number=True)
                if not self.crfeeling == self.sentimentv:
                    log(f"[JarvisProject now feels: {self.sentimentv}]", style="bold white")
                    self.crfeeling = self.sentimentv
        
        if bye:
            # Check if the AI still wants to talk to the user
            if (("bye" in self.outputlist) or ("goodbye" in self.outputlist)):
                notalk = "It seems JarvisProject no longer wishes to speech to you."
                if self.speech == "both":
                    log(notalk)
                    Thread(target= lambda: say(notalk))
                elif self.speech:
                    Thread(target= lambda: say(notalk))
                else:
                    log(notalk)
                
                forcecontinue = "Not Set"
                if not self.bypass:
                    while not ((forcecontinue == "Y") or (forcecontinue == "N")):
                        forcecontinue = inputl("Would you like to force JarvisProject to continue to talk with you? (Y/N): ")
                    if forcecontinue == "N":
                        log("Exiting...", style="blink bold red")
                        return True
                    else:
                        log("Force continuing...", style="bold red")
                        return False

    @logger.catch
    def listenvoice(self, delete: bool = True):
        """Listens to user's microphone and converts it to text.

        Args:
            delete (bool, optional): Delete the printed log text. Defaults to True.

        Returns:
            str: The text detected from the microphone
        """
        log = self.log
        r = sr.Recognizer()
        with sr.Microphone() as source:
            log("Listening for Voice...")
            audio = r.listen(source)
            if delete:
                cls(self.bypass)
            return r.recognize_google(audio)
    
    @staticmethod
    @logger.catch
    def sentiment(sentence: str, both: bool = False, number: bool = False, store = False):
        """Get sentiment of sentence.

        Args:
            sentence (str): Sentence to analyse.
            both (bool, optional): Get the score as a string and int. Defaults to False.
            number (bool, optional): Get score as only int. Defaults to False.
            store (bool, optional): Used for multiprocessing.Manager(). Defaults to False.

        Raises:
            NoText: No text was given.

        Returns:
            str / str | int: Score of sentence.
        """
        if sentence == "":
            raise NoText("No text was given!")
        sia = SentimentIntensityAnalyzer()
        score = sia.polarity_scores(sentence)["compound"]

        def put(sc: str):
            if both:
                store["return"] = sc, score
            else:
                store["return"] = sc

        if not store is False:
            if number:
                store["return"] = score
            if score == 0:
                put("neutral")
            elif score > 0:
                put("positive")
            else:
                put("negative")
        else:
            if both:
                if score == 0:
                    return "neutral", score
                elif score > 0:
                    return "positive", score
                else:
                    return "negative", score
            else:
                if number:
                    return score
                if score == 0:
                    return "neutral"
                elif score > 0:
                    return "positive"
                else:
                    return "negative"

    @logger.catch
    def save(self):
        """Ask user if they want to save the current model and tokenizer if bypass is False"""
        log = self.log
        if not self.bypass:
            save = "Not Set"
            while not ((save == "Y") or (save == "N")):
                save = inputl("Would you like to save the current JarvisProject profile? (Y/N): ")
            if save == "Y":
                name = inputl("\nWhat do you want to name the profile (This name is needed for loading the profile)?: ")
                if name == "FastBoot":
                    log("You can not use that profile name. You need to manually override this profile. The name has been changed to 'Unnamed'.")
                    name = "Unnamed"
                if os.path.isdir(os.path.expanduser('~') + "/Documents/JarvisProject/profiles/" + name):
                        while not ((save == "Y") or (save == "N")):
                            save = inputl("Are you sure you want to overwrite an existing profile? (Y/N): ")
                        if save == "Y":
                            log("Overwriting an existing profile...")
                        else:
                            exit()
                log("Saving profile...", style="blink bold green")
                self.name = name
                self.savemodel()
                cls(self.bypass)
                log("Profile Saved!", style="bold green")
            else:
                log("Quiting...", style="red")

if __name__ == "__main__":
    chkargs()
    m = Main("Default", speech=False)
    Chart.emcreate()
