import os
import sys
import time as timer
from configparser import ConfigParser

import requests

if os.name == "nt":
    import ctypes

import http.client as httplib
import re
from datetime import datetime, timezone
from distutils.dir_util import copy_tree

try:
    import geocoder
    geocoder_status = True
except Exception:
    geocoder_status = False

try:
    import mss
    import mss.tools
    mss_status = True
except Exception:
    mss_status = False

try:
    import pytz
    pytz_status = True
except Exception:
    pytz_status = False

from loguru import logger
from rich.console import Console

logger.add(os.path.expanduser("~") + "/Documents/JarvisProject/logs/debug/" + os.path.split(__file__)[1][:-3] + ".log", retention="10 days", backtrace=True, diagnose=True)


# Errors
class ModuleNotInstalled(Exception):
    pass

@logger.catch
def copy(dir: str, newdir: str, name: str):
    """Copies a folder structure and creates it if it does not exist.

    Args:
        dir (str): Directory to copy
        newdir (str): Folder to copy to
        name (str): Name of the folder
    """
    if not os.path.isdir(newdir):
        make(newdir, newdir)
    try:
        copy_tree(dir, newdir)
        log("main.py", f"Copied over {name}.", style = "green")
    except Exception as e:
        log("main.py", f"Error copying {name}: " + str(e), style = "bold red")

@logger.catch
def make(mdir: str, name: str):
    if not os.path.isdir(mdir):
        os.mkdir(mdir)
        log("main.py", f"Made {name} directory.", style = "green")

@logger.catch
def check_run() -> RuntimeError:
    if not os.path.isdir(dir):
        raise RuntimeError(f"Storage Directory does not exist! Please run main.py before running this module.")

@logger.catch
def wconfig(section = "[main]", name = "Unknown", data = "Unknown"):
    """Writes to the configuration file.

    Args:
        section (str): The section to write to.
        name (str): The name of the variable to write to.
        data (str): The data to store with the variable.
    """
    config = ConfigParser()
    config.read(resource_path('config.ini'))
    config[section][name] = data
    with open(resource_path('config.ini'), 'w') as configfile:
        config.write(configfile)

@logger.catch
def rconfig(section = "settings", name = "Unknown"):
    """Reads from the configuration file.

    Args:
        section (str): The section to read from.
        name (str): The name of the variable to read from.
    
    Returns:
        str: The data stored with the variable.
    """
    configfile = resource_path('config.ini')
    config = ConfigParser()
    try:
        config.read(configfile)
    except Exception as e:
        print(str(e))
    data = config.get(section, name)
    try:
        return float(data)
    except:
        try:
            return int(data)
        except:
            try:
                return bool(data)
            except:
                return str(data)

@logger.catch
def userprofile(dir: str) -> str:
    """Gets the user profile directory of the given argument.

    Args:
        dir (str): Directory Name to search for.

    Returns:
        str: The directory with the user profile
    """
    return os.environ['USERPROFILE'] + "/" + dir
    
@logger.catch
def remove_ansi_escape_seq(text: str) -> str:
    """Removes ANSI escape sequences (such as a colorama color
    code) from a string so that they aren't spoken.

    Args:
        text (str): The text that may contain ANSI escape sequences.

    Returns:
        str: The text with ANSI escape sequences removed.
    """
    text = re.sub(r'''(\x9B|\x1B\[)[0-?]*[ -\/]*[@-~]''', '', text)
    return text

@logger.catch
def screenshot(destination = dir) -> str:
    """Takes a screenshot.

    Returns:
        str: Screenshot file name.
    """
    timer.sleep(1)
    if not mss_status:
        raise ModuleNotInstalled("Install the python package 'mss' to use this function!")
    with mss.mss() as sct:
        filename = sct.shot()
        os.rename(filename, destination)
        log("functions.py", "Taken Screen Shot: " + filename)
    return filename
    
@logger.catch
def getscreenhight() -> int:
    """Gets the screen's hight. Defaults to 1920 if not Windows.
    
    Returns:
         int: Screen's hight.
    """
    if os.name == "nt":
        user32 = ctypes.windll.user32
        screensize = user32.GetSystemMetrics(1)
    else:
        screensize = 1920
    return int(screensize)

@logger.catch
def getscreenwidth() -> int:
    """Gets the screen's width. Defaults to 1080 if not Windows.
    
    Return:
         int: Screen's width.
    """
    if os.name == "nt":
        user32 = ctypes.windll.user32
        screensize = user32.GetSystemMetrics(0)
    else:
        screensize = 1080
    return int(screensize)

@logger.catch
def firststart() -> bool:
    """
    Checks if Jarvis-Project has been packaged using PyInstaller.
    It does this by trying 'sys._MEIPASS'.
    Returns:
        True / False (True if packaged in PyInstaller)
    """
    try:
        sys._MEIPASS # Checks if packaged used PyInstaller
        return True
    except:
        return False

@logger.catch
def strtolist(str) -> str:
    """
    Converts a string to a list using 're' module
    :param str: The string to convert to a list
    Returns:
        The string as a list (list object)
    """
    try:
        return re.sub("[^\w]", " ",  str).split()
    except Exception as e:
        return str(e)

@logger.catch
def getloc(toget: str = "city"):
    """
    Gets the current device location based of thier IP Address
    Returns:
        Current Location (City)
    """
    if not geocoder_status:
        log("functions.py", "geocoder not installed!", noprint=True)
        raise ModuleNotInstalled("Install the python package 'geocoder' to use this function!")
    g = geocoder.ip('me')
    if toget == "lat":
        return g.lat
    elif toget == "lng":
        return g.lng
    elif toget == "city":
        return g.city
    else:
        return g

@logger.catch
def weather(latitude = False, longitude = False, timezone = False) -> dict:
    """
    Gets the weather from a City Name
    :param city: The city name to get the weather from. If no argument is provided, it gets the city using getcity().
    Returns:
        owm.weather_manager object
    """
    if not latitude:
        latitude = getloc("lat")
        print(latitude)
    if not longitude:
        longitude = getloc("lng")
        print(longitude)
    if not timezone:
        timezone = getloc("city")
        print(timezone)
    url = "https://api.open-meteo.com/v1/forecast?latitude=" + str(latitude) + "&longitude=" + str(longitude) + "&hourly=temperature_2m,apparent_temperature,precipitation,snow_depth&daily=temperature_2m_max,temperature_2m_min&timezone=Europe/London"
    print(url)
    header = {'x-requested-with': 'XMLHttpRequest'}
    t = requests.get(url, headers=header)
    observation = t.json()
    return observation

@logger.catch
def internet() -> bool:
    """
    Checks if the user is connected to the internet by pinging Google DNS Servers.
    Returns:
        True / False (True if the user has an internet connection)
    """
    conn = httplib.HTTPSConnection("8.8.8.8", timeout=5)
    try:
        conn.request("HEAD", "/")
        return True
    except Exception:
        return False
    finally:
        conn.close()

@logger.catch
def resource_path(relative_path: str, dir: str = os.path.expanduser('~') + "/Documents/JarvisProject") -> str:
    """
    Locate the file / folder in the Documents/JarvisProject Folder
    Args:
        relative_path (str): The file / folder to find
        dir (str, optional): The dir to find in
    Returns:
        (str): The location of the file / folder
    """
    if not os.path.isdir(dir):
        os.mkdir(dir)
    return dir + "/" + relative_path

def relative_path(relative_path, dir = os.path.expanduser('~') + "/Documents/JarvisProject") -> str:
    """Gets the output of resource_path() and returns it

    Args:
        relative_path (str): The file / folder to find
        dir (str, optional): The dir to find in
    
    Returns:
        (str): The location of the file / folder
    """
    return resource_path(relative_path, dir)

@logger.catch
def timeday():
    """
    Unknown
    """
    if not geocoder_status:
        log("functions.py", "geocoder not installed!", noprint=True)
        raise ModuleNotInstalled("Install the python package 'geocoder' to use this function!")
    
    utc_dt = datetime.now(timezone.utc) # UTC time
    dt = utc_dt.astimezone(pytz.timezone('Europe/London'))
    dt = dt.date()
    return dt

@logger.catch
def daytime():
    """
    Gets the current day and time
    Returns:
        Day/Month/Yeah, Hours/Minutes/Seconds
    """
    dt = datetime.now()
    dt = dt.strftime("%d/%m/%Y, %I:%M %p")
    return dt

@logger.catch
def time():
    """
    Gets the current time
    Returns:
        Hours/Minutes/Seconds
    """
    if not geocoder_status:
        log("functions.py", "geocoder not installed!", noprint=True)
        raise ModuleNotInstalled("Install the python package 'geocoder' to use this function!")
    
    utc_dt = datetime.now(timezone.utc) # UTC time
    dt = utc_dt.astimezone(pytz.timezone('Europe/London'))
    dt = dt.strftime("%I:%M %p")
    return dt

@logger.catch
def log(name: str, event: str, passargs: str = False, style: str = "default", noprint: bool = False):
    """
    Logs an event into logs/log.log
    
    Args:
        name (str): The module name which this function is being called from.
        event (str): The event that has occurred with this module.
        passargs (str): Optional argument that can contain more infomation about the event. Defaults to False.
        style (str): Optional argument that can be used for rich text. Defaults to "default".
    """
    console = Console()
    print = console.print
    dt = datetime.now()
    dt = dt.strftime("%m/%d/%Y, %I:%M %p")
    if not os.path.isdir(resource_path("logs")):
        os.mkdir(resource_path("logs"))
    
    def write(file):
        if not os.path.isfile(resource_path(f"logs/{file}.log")):
            with open(resource_path(f"logs/{file}.log"), 'w') as f:
                f.write("Created log")
        
        if file == "log":
            with open(resource_path(f"logs/{file}.log"), 'a') as f:
                f.write("\n" + dt + ": " + name + " - " + event)
                if passargs:
                    f.write(passargs)
        else:
            with open(resource_path(f"logs/{file}.log"), 'a') as f:
                f.write("\n" + dt + ": " + event)
                if passargs:
                    f.write(passargs)
    if not noprint:
        if passargs:
            print(event + ", " + passargs, style=style)
        else:
            print(event, style=style)
        
    write("log")
    write(name[:-3])

@logger.catch
def text2int(textnum, numwords={}):
    """
    Converts text of numbers given to a int.
    :param textnum: str of number. e.g: 'one'.
    Returns:
        Gives the int version of the textnum
    """
    if not numwords:
        units = [
            "zero", "one", "two", "three", "four", "five", "six", "seven", "eight",
            "nine", "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen",
            "sixteen", "seventeen", "eighteen", "nineteen",
        ]
        tens = ["", "", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety"]
        scales = ["hundred", "thousand", "million", "billion", "trillion"]
        numwords["and"] = (1, 0)
        for idx, word in enumerate(units):    numwords[word] = (1, idx)
        for idx, word in enumerate(tens):     numwords[word] = (1, idx * 10)
        for idx, word in enumerate(scales):   numwords[word] = (10 ** (idx * 3 or 2), 0)
    current = result = 0
    for word in textnum.split():
            if word not in numwords:
                raise Exception("Illegal word: " + word)
            scale, increment = numwords[word]
            current = current * scale + increment
            if scale > 100:
                    result += current
                    current = 0
    return result + current
