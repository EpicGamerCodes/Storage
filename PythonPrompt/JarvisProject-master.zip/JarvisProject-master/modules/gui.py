import ctypes
import os
import warnings
from datetime import datetime
from threading import Thread
from tkinter import *
from tkinter import ttk

from loguru import logger
from PIL import Image, ImageTk
from rich.console import Console
from transformers import BertTokenizer, BertModel

try:
    import modules.chat as chat
    from modules.functions import *
except ImportError:
    import chat as chat
    from functions import *

import time # To overwrite functions.time

os.environ["CURL_CA_BUNDLE"] = "" # To fix auth errors

dir = os.path.expanduser('~') + "/Documents/JarvisProject"
warnings.filterwarnings("ignore")
logger.add(os.path.expanduser("~") + "/Documents/JarvisProject/logs/debug/" + os.path.split(__file__)[1][:-3] + ".log", retention="10 days", backtrace=True, diagnose=True)

@logger.catch
def log(event: str, passargs: str = False, style: str = "default", noprint: bool = False):
    """
    Logs an event into logs/log.log
    
    Args:
        event (str): The event that has occurred with this module.
        passargs (str): Optional argument that can contain more infomation about the event. Defaults to False.
        style (str): Optional argument that can be used for rich text. Defaults to False.
    """
    console = Console()
    print = console.print
    name = "gui"
    dt = datetime.now()
    dt = dt.strftime("%m/%d/%Y, %I:%M %p")
    if not os.path.isdir(resource_path("logs")):
        os.mkdir(resource_path("logs"))
    
    def write(file):
        if not os.path.isfile(resource_path(f"logs/{file}.log")):
            with open(resource_path(f"logs/{file}.log"), 'w') as f:
                f.write("Created log")
        
        with open(resource_path(f"logs/{file}.log"), 'a') as f:
            f.write("\n" + dt + ": " + event)
            if passargs:
                f.write(passargs)
                
    if not noprint:
        if passargs:
            print(name + " : " + event + ", " + passargs, style=style)
        else:
            print(name + " : " + event, style=style)
        
    write("log")
    write(name[:-3])

class Create:
    @staticmethod
    @logger.catch
    def window(title: str, size: list = [200, 200]):
        window = Toplevel()
        window.title(title)
        window = Tools.center_window(window, size)
        window.iconphoto(False, PhotoImage(file=resource_path("icon.png")))
        return window
    
    @staticmethod
    @logger.catch
    def button(window, label: str, command, ret: bool = False):
        btn = ttk.Button(window, text=label, command=command, style="Accent.TButton")
        btn.pack(pady=10)
        if ret:
            return btn
    
    @staticmethod
    @logger.catch
    def text(window, text: str, edit: bool = False, height: int = 12, width: int = 40, font: tuple = ("Segoe UI Variable Text", 18)):
        txt = Text(window, height = height, width = width)
        txt.configure(font=font)
        txt.insert('end', text)
        if not edit:
            txt.config(state='disabled')
        return txt

class Tools:
    @staticmethod
    @logger.catch
    def center_window(window, size: list = [320, 200]):
        window_width = size[0]
        window_height = size[1]
        window_x = int((window.winfo_screenwidth() / 2) - (window_width / 2))
        window_y = int((window.winfo_screenheight() / 2) - (window_height / 2))

        window_geometry = str(window_width) + 'x' + str(window_height) + '+' + str(window_x) + '+' + str(window_y)
        window.geometry(window_geometry)
        return window

class Event:
    @staticmethod
    @logger.catch
    def voice_commands():
        def start_apps():
            window = Create.window("Voice Commands: Start Apps")
            lbl = ttk.Label(window, text="In the works (TBD)...")
            lbl.pack(pady=10)
        
        def start_ai():
            window = Create.window("Voice Commands: Start AI")
            lbl = ttk.Label(window, text="In the works (TBD)...")
            lbl.pack(pady=10)
        
        window = Create.window("Voice Commands")
        Create.button(window, "Start Apps", start_apps)
        Create.button(window, "Start AI", start_ai)

    @staticmethod
    @logger.catch
    def create_command():
        def create_cmd(starter):
            print(starter.get())
        
        window = Create.window("Create Commands", [320, 200])
        starter = ttk.Combobox(window, values=["start", "check", "find"])
        starter.current(0)
        starter.pack(anchor=SW)
        Create.button(window, "Create Command", lambda: create_cmd(starter))

class Main:
    @staticmethod
    @logger.catch
    def create_window(title: str, center: bool = False, size: list = [320, 200], icon: str = resource_path("icon.png")):
        window = Tk()
        window.tk.call("source", resource_path("themes/windows.tcl"))
        window.tk.call("set_theme", "dark")
        window.title(title)
        window.iconphoto(False, PhotoImage(file=icon))
        window.minsize(height=window.winfo_screenheight(), width=window.winfo_screenwidth())
        ctypes.windll.shcore.SetProcessDpiAwareness(1)
        if center:
            window = Tools.center_window(window, size)
        return window

class Help:
    @staticmethod
    @logger.catch
    def help():
        window = Main.create_window("JarvisProject Help", center=True)
        Create.button(window, "Voice Commands", Event.voice_commands)
        Create.button(window, "Create Commands", Event.create_command)
        window.mainloop()

class AutoComplete:
    @logger.catch
    def __init__(self):
        self.tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')
        self.model = BertModel.from_pretrained("bert-base-uncased")
        self.output = None
        self.output_list = []
        self.menu = "Placeholder"
    
    @logger.catch
    def predict(self, request: str):
        try:
            self.encoded_input = self.tokenizer(request, return_tensors='pt')
            self.output = self.model(**self.encoded_input)
        except Exception:
            return None
        
        self.output_list = []
        for i in range(len(self.output)):
            self.output_list.append(i["token_str"])
        return self.output_list
        
class AI_GUI:
    @logger.catch
    def __init__(self, window_name: str = "JarvisProject AI GUI", talk_name: str = "GUI", debug: bool = True, save_on_close: bool = True):
        log = self.log
        self.debug = debug
        self.save_on_close = save_on_close
        log("\n-----------------------------\n")
        self.window_name = window_name
        self.talk_name = talk_name
        log(f"Window made with title: {window_name}")
        self.window = Main.create_window(window_name, center=True)
        self.window.state("zoomed")
        self.talk = chat.Main(talk_name, bypass=True, speech=False)
        self.talk.ret = True
        if os.path.isdir(os.path.expanduser('~') + "/Documents/JarvisProject/profiles/GUI"):
            self.talk.loadmodel(os.path.expanduser('~') + "/Documents/JarvisProject/profiles/GUI")
        log(f"Chat Engine made with name: {self.talk_name}")
        self.ac = AutoComplete()
    
    def log(self, event: str, passargs: str = False, noprint: bool = False, style: str = "default"):
        if self.debug:
            log(event=event, passargs=passargs, noprint=False, style=style)
        else:
            log(event=event, passargs=passargs, noprint=noprint, style=style)
    
    @logger.catch
    def button(self, label: str, command, ret: bool = False):
        log = self.log
        btn = ttk.Button(self.window, text=label, command=command, style="Accent.TButton")
        btn.pack(pady=10)
        log(f"Text box created, {label=}, {command=}, {ret=}")
        if ret:
            return btn
    
    @logger.catch
    def text(self, default_text: str = None, edit: bool = False, height: int = 12, width: int = 40, font: tuple = ("Segoe UI Variable Text", 18)):
        log = self.log
        txt = Text(self.window, height=height, width=width)
        txt.configure(font=font)
        if not default_text is None:
            txt.insert('end', default_text)
        if not edit:
            txt.config(state='disabled')
        log(f"Text box created, {default_text=}, {edit=}, {height=}, {width=}, {font=}")
        return txt
    
    @logger.catch
    def bind_(self, widget, all_=False, modifier="", letter="", callback=None, add='',):
        if modifier and letter:
            letter = "-" + letter
        if all_:
            widget.bind_all('<{}{}>'.format(modifier, letter.upper()), callback, add)
            widget.bind_all('<{}{}>'.format(modifier, letter.lower()), callback, add)
        else:
            widget.bind('<{}{}>'.format(modifier, letter.upper()), callback, add)
            widget.bind('<{}{}>'.format(modifier, letter.lower()), callback, add)
    
    @logger.catch
    def writeToLog(self, msg):
        self.log_window['state'] = 'normal'
        if self.log_window.index('end-1c')!='1.0':
            self.log_window.insert('end', '\n')
        self.log_window.insert('end', msg)
        self.log_window['state'] = 'disabled'
        self.log_window.see(END)
    
    def ac_popup(self):
        self.ac.menu = Menu(self.window, tearoff=0)
        lines = self.jptxt.get(float(self.jptxt.index('end-1c linestart'))-1, END)
        text = f"{lines.strip()}"
        output = self.ac.predict(text + "[MASK]")
        #while not len(self.ac.output_list) == 5: # Causes ValueError if too many values to unpack
        #    del self.ac.output_list[-1]
        if output is None:
            return None
        
        suggest0, suggest1, suggest2, suggest3, suggest4 = output
        self.ac.menu.add_command(label=suggest0, command=lambda: self.jptxt.insert("end", suggest0))
        self.ac.menu.add_command(label=suggest1, command=lambda: self.jptxt.insert("end", suggest1))
        self.ac.menu.add_command(label=suggest2, command=lambda: self.jptxt.insert("end", suggest2))
        self.ac.menu.add_command(label=suggest3, command=lambda: self.jptxt.insert("end", suggest3))
        self.ac.menu.add_command(label=suggest4, command=lambda: self.jptxt.insert("end", suggest4))
        
    @logger.catch
    def update_chart(self):
        global image
        self.talk.emcreate(os.path.expanduser("~") + "/Documents/JarvisProject/emchart.png")
        image = ImageTk.PhotoImage(Image.open(os.path.expanduser("~") + "/Documents/JarvisProject/emchart.png"))
        chart = Label(self.window, image=image)
        chart.place(relx=1.0, rely=1.0, anchor='se')
        score = next(reversed(self.talk.data.emotions.values()))
        if score == 0:
            self.writeToLog(f"JarvisProject is feeling: Neutral ({score})")
        elif score > 0:
            self.writeToLog(f"JarvisProject is feeling: Positive ({score})")
        else:
            if score <= -0.8:
                self.writeToLog(f"WARNING: JarvisProject's Emotion level is very low!")
            self.writeToLog(f"JarvisProject is feeling: Negative ({score})")

    @logger.catch
    def ai_request(self):
        self.request()
        self.talk.checktalk()
        self.jptxt.see(END)
        Thread(target=self.update_chart).start()

    def save_mind(self):
        log = self.log
        def validate(window, input):
            try:
                int(input.get())
                float(input.get())
                txt = Create.text(window, text="That is not a string!", font=("Segoe UI Variable Text", 15))
                txt.pack()
                input.state(["invalid"])
                log(f"    >> String type not given!")
            except Exception:
                if input.get() == "":
                    txt = Create.text(window, text="Please enter a name for the profile!", font=("Segoe UI Variable Text", 15))
                    txt.pack()
                    input.state(["invalid"])
                    log(f"    >> Invalid name for saving profile!")
                else:
                    save(window, input.get())
                    window.destroy()
                    log("    >> Saving Profile Window closed")

        def save(window, name: str):
            try:
                self.talk.savemodel(name=name)
                log(f">> Saved profile as: '{name}'")
            except Exception as e:
                txt = Create.text(window, text=">> An Error Occurred!", font=("Segoe UI Variable Text", 15))
                txt.pack()
                log(str(e))
        
        window = Create.window("Save as Profile")
        entry = ttk.Entry(window)
        entry.pack()
        savebtn = Create.button(window, "Save", lambda: validate(window, entry), ret=True)
        savebtn.config(width=100)
        log("> Saving Profile Window created!")
        window.mainloop()
        log("    >> Saving Profile Window closed")
    
    @logger.catch
    def change_temperature(self):
        log = self.log
        def validate(window, input):
            inputdata = input.get()
            try:
                if inputdata == "default":
                    inputdata = 0.75
                float(inputdata)
                self.talk.temperature = float(inputdata)
                window.destroy()
                log("    >> Saving Profile Window closed")
                log("    >> Saved talk.temperature as: '" + float(inputdata) + "'")
            except:
                txt = Create.text(window, text="That is not a float!", font=("Segoe UI Variable Text", 15))
                txt.pack()
                input.state(["invalid"])
                log(f"    >> Invalid type, not given a float!")
        
        window = Create.window("Change AI temperature")
        entry = ttk.Entry(window)
        entry.pack()
        savebtn = Create.button(window, "Change", lambda: validate(window, entry), ret=True)
        savebtn.config(width=100)
        log("> Change Temperature Window created!")
        window.mainloop()
        log("    >> Change Temperature Window closed")

    @logger.catch
    def reset(self):
        log = self.log
        t = time.strftime("%H:%M:%S")
        self.talk = chat.Main("Reset GUI", bypass=True, speech=False)
        self.talk.ret = True
        self.talk.data.usremotions[t] = 0.0
        self.talk.data.emotions[t] = 0.0
        self.update_chart()
        log("Reset self.talk!", style="bold red")
        self.window.destroy()
        self.window = Main.create_window(self.window_name, center=True)
        self.window.state("zoomed")
        self.launch()

    @logger.catch
    def request(self):
        log = self.log
        lines = self.jptxt.get(float(self.jptxt.index('end-1c linestart'))-1, END)
        data = f"{lines.strip()}"
        data = data.replace(">> You: ", "")
        data = data.replace(">> You:", "") # In case user has deleted the space in front of the colon
        log(f"Request: '{data.strip()}'")
        text = self.talk.talk(data.strip())
        log(f"Responce: '{text}'")
        self.jptxt.insert(END, "\nJarvisProject: " + text + "\n>> You: ")

    @logger.catch
    def do_popup(self, event):
        try:
            self.right_click.tk_popup(event.x_root, event.y_root)
        finally:
            self.right_click.grab_release()
    
    @logger.catch
    def launch(self):
        log = self.log
        log(f"Launching with name: {self.talk_name}, window_name: {self.window_name}.")
        info = f"""Instance Name: {self.talk.name}
Speak Mode:  {self.talk.speech}
Bypass Mode: {self.talk.bypass}
Listen Mode: {self.talk.listen}
Return Mode: {self.talk.ret}
"""
        self.log_window = self.text(default_text=info, height=5, width=50)
        self.log_window.pack(side="right", anchor=NW)
        log("self.log Packed")
        self.jptxt = self.text(edit=True, height=self.window.winfo_screenheight(), width=50)
        self.jptxt.pack(side="left")
        log("self.jptxt Packed")
        self.jptxt.focus()
        log("self.jptxt Focused")
        self.button("Save profile", self.save_mind)
        self.button("Change AI temperature", self.change_temperature)
        self.button("Reset", self.reset)
        self.jptxt.bind("<Return>", lambda x=None: self.ai_request())
        log("[Enter] (<Return>) in self.jptxt binded to 'lambda x=None: self.ai_request())'")

        self.right_click = Menu(self.window, tearoff=0)
        self.right_click.add_command(label="Cut",  accelerator="Ctrl+X", command=lambda: self.jptxt.event_generate("<<Cut>>"))
        self.right_click.add_command(label="Copy", accelerator="Ctrl+C", command=lambda: self.jptxt.event_generate("<<Copy>>"))
        self.right_click.add_command(label="Paste",  accelerator="Ctrl+V", command=lambda: self.jptxt.event_generate("<<Paste>>"))
        self.right_click.add_separator()

        log("[Control + X] (<Control-X>) in self.window binded to 'self.jptxt.event_generate(\"<<Cut>>\")'")
        log("[Control + C] (<Control-C>) in self.window binded to 'self.jptxt.event_generate(\"<<Copy>>\")'")
        log("[Control + P] (<Control-P>) in self.window binded to 'self.jptxt.event_generate(\"<<Paste>>\")'")

        self.right_click.add_command(label="Save profile", accelerator="Ctrl+S", command=self.save_mind)
        self.right_click.add_command(label="Change AI temperature", accelerator="Ctrl+T", command=self.change_temperature)
        self.right_click.add_command(label="Reset", accelerator="Ctrl+R", command=self.reset)
        self.window.bind("<Button-3>", self.do_popup)
        self.bind_(self.window, modifier="Control", letter="s", callback=lambda x=None, y=None: self.save_mind())
        self.bind_(self.window, modifier="Control", letter="t", callback=lambda x=None, y=None: self.change_temperature())
        self.bind_(self.window, modifier="Control", letter="r", callback=lambda x=None, y=None: self.reset())

        log("[Control + R] (<Control-R>) in self.window binded to 'self.reset'")
        log("[Control + R] (<Control-R>) in self.window binded to 'self.reset'")
        log("[Control + S] (<Control-S>) in self.window binded to 'self.save_mind'")
        log("[Control + T] (<Control-T>) in self.window binded to 'self.change_temperature'")
        log("[Control + R] (<Control-R>) in self.window binded to 'self.reset'")
        log("[Right Click] (<Button-3>) in self.window binded to 'self.do_popup', which is controling 'self.right_click'")
        
        # TO FIX
        #letters = ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"]
        #for i in letters:
        #    self.jptxt.bind(i, lambda x=None: self.ac_popup())

        if not self.talk.data.responce == []: # Load previous text messages
            Thread(target=self.update_chart()).start()
            for i in range(len(self.talk.data.responce)):
                usrtext = self.talk.data.usrrequest[i]
                resptext = self.talk.data.responce[i]

                self.jptxt.insert(END, "\n>> You: \n" + usrtext)
                self.jptxt.insert(END, "\nJarvisProject: " + resptext)
            self.jptxt.insert(END, "\n")
        
        self.jptxt.insert(END, ">> You: \n")
        self.jptxt.see(END)

        self.window.mainloop()
        if self.save_on_close:
            self.talk.savemodel(overwrite=True)

if __name__ == "__main__":
    window = AI_GUI()
    window.launch()
else:
    log("JarvisProject (/modules/gui.py) was imported as a module")
