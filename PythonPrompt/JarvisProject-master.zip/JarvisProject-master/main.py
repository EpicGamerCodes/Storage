import argparse
import os
import shutil
import sys
from pathlib import Path
import requests

try:
    # PyInstaller creates a temp folder and stores path in _MEIPASS
    os.chdir(sys._MEIPASS)
except:
    pass

import modules.chat as chat
import modules.gui as gui
import modules.listen as listen
import modules.screenrecord as screenrecord
import modules.taskbar as taskbar
from modules.functions import *

def run(module):
    try:
        if os.name == "nt":
            os.system("py " + globals()[module].__file__)
        else:
            os.system("python3 " + globals()[module].__file__)
    except Exception as e:
        print(str(e))
    exit()

parser = argparse.ArgumentParser()

parser.add_argument("-v", "--version", action='store_true', help='Get the Current Version.')
parser.add_argument("--offline", action="store_true", help='Uses all the offline modules and does not use the internet (Enabled by default if the device is not connected to the internet).')
parser.add_argument("-nv", "--no-voice", action="store_true", help='Disables the voice in listen.py')
parser.add_argument("-nt", "--no-tray", action="store_true", help="Disables the system tray icon in taskbar.py")
parser.add_argument("-isa", "--ignore-start-aliases", action="store_true", help='Ignores the "start" Voice Command app aliases in listen.py')
parser.add_argument("-i", "--install", action='store_true', help='Install JarvisProject to the Documents folder and it can be run from anywhere')
parser.add_argument("--run", action='store', help='Run a JarvisProject module.', default=False)

args=parser.parse_args()
if args.version:
    log("main.py", "Version: 1.0.0")
    exit()
if args.offline:
    wconfig(name="offline", data="True")
if args.no_voice:
    wconfig(name="no_voice", data="True")
if args.no_tray:
    wconfig(name="no_tray", data="True")
if args.ignore_start_aliases:
    wconfig(name="isa", data="True")
if args.install:
    dir = os.path.expanduser('~') + "/Documents/JarvisProject"
    if not os.path.isdir(dir):
        os.mkdir(dir)
        os.mkdir(dir + "/app")
    copy(Path(__file__).resolve().parent, dir + "/app")
    log("install.py", "Files copied over...")
    os.environ['PATH'] += ';' + dir + "/app"
    log("install.py", "Added to PATH")
if args.run:
    run(args.run)

def setup(dir: str = os.path.expanduser('~') + "/Documents/JarvisProject"): 
    make(dir, "main")
    make(dir + "/logs", "logs")
    
    copy("voicefiles", dir + "/voicefiles", "voicefiles")
    copy("shortcuts", dir + "/shortcuts", "shortcuts")
    copy("fonts", dir + "/fonts", "fonts")
    copy("themes", dir + "/themes", "themes")
    shutil.copyfile("icon.png", dir + "/icon.png")
    shutil.copyfile("icon.ico", dir + "/icon.ico")
    
    url = 'https://github.com/EpicGamerCodes/JarvisProject/tree/master'
    r = requests.get(url)
    version = r.url.split('/')[-1]

    try:
        with open(resource_path("config.ini"), "w+") as f:
            f.write(f'''[settings]
version={version}
offline="False"
no_voice="False"
no_tray="False"
isa="False"
''')
    except Exception as e:
        log("main.py", "Error creating config.ini: " + str(e), style="bold red")
    
    log("main.py", "Setup Complete!", style="blink bold green")

if not os.path.isdir(os.path.expanduser('~') + "/Documents/JarvisProject/config.ini"):
    setup()

log("main.py", "JarvisProject Modules has started up at: " + str(time()) + "!", style="bold green")

if firststart():
    print("""Welcome to JarvisProject Pre-Alpha.
This is a work in progress and features may not work as intended.
An Internet Connection is requred for Voice Commands to work. Offline Mode will come soon.
To make the Project listen to your voice, use the right click menu and click 'Listen for Voice Command'.
Voice Commands Are:
help (recommeneded)
start [app name] (only works with default install directories)
joke
volume [2 - 100] (sets the volume)
increase volume [2 - 100] (increases the volume)
decrease volume [2 - 100] (decreases the volume)
say [text]
take screenshot
""")

taskbar.start()

log("main.py", "An error occurred", "Modules Function Passed", style="blink bold red")
